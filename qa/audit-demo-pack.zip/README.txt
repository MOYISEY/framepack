Framepack image handoff

Copy assets/ into your site and adapt responsive.html to your layout. Width descriptors match the encoded pixel dimensions. Edit sizes for your CSS layout. Empty alt means decorative; write meaningful alt text for content images.

Original files are not included or modified. Canvas re-encoding can change color profiles and metadata; this is not a forensic metadata scrubber. Quality applies to JPEG/WebP; PNG is lossless. Variants can be larger than originals. The sum of a responsive set is not a per-image saving.
